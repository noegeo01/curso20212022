<?php
    echo "No es zona admin";
?>