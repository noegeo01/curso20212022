<?php
    include 'matematicas.php';
    $a=2;
    $b=4;
    $c=1;

    $respuesta=resolverEcua_grado2($a,$b,$c);
    echo $respuesta;
?>